package com.example.demo.restcontroller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SampleControllerTesting {
	@GetMapping("/")
	public String testingEndPoint() {
		return "HEy Application is working";
	}

}
