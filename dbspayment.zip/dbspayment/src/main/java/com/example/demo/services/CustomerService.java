package com.example.demo.services;

import java.util.List;

import com.example.demo.model.Customer;

public interface CustomerService {
	public Boolean add(Customer customer);
	public Boolean update(Customer customer);
	public Boolean delete(Customer customer);
	public Boolean save(Customer customer);
	public List<Customer> list();
	


}
