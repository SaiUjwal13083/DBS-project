package com.example.demo.services;

import java.util.List;

import com.example.demo.model.Customeruser;

public interface CustomeruserService {
	public Boolean add(Customeruser customeruser);
	public Boolean update(Customeruser customeruser);
	public Boolean delete(Customeruser customeruser);
	public Boolean save(Customeruser customeruser);
	public List<Customeruser> list();
	


}
