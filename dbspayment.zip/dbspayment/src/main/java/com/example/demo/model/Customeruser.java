package com.example.demo.model;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity

public class Customeruser implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7715631267243116178L;
	@Id
	private Integer userId;
	@Column(length = 11)
	private String userName;
	@Column(unique = true)
	private Customer customerId;
	@Column(length = 11)
	private String userPassword;
	@Column(length = 100)
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Customer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Customer customerId) {
		this.customerId = customerId;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public int hashCode() {
		return Objects.hash(customerId, userId, userName, userPassword);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customeruser other = (Customeruser) obj;
		return Objects.equals(customerId, other.customerId) && Objects.equals(userId, other.userId)
				&& Objects.equals(userName, other.userName) && Objects.equals(userPassword, other.userPassword);
	}
	@Override
	public String toString() {
		return "Customeruser [userId=" + userId + ", userName=" + userName + ", customerId=" + customerId
				+ ", userPassword=" + userPassword + "]";
	}
	
	
	
		
	

}
