package com.example.demo.serviceImpl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.model.Logger;
import com.example.demo.repositories.LoggerRepository;
import com.example.demo.services.LoggerService;
@Service
public class LoggerServiceImpl implements LoggerService {
	private LoggerRepository loggerRepository;

	@Override
	public Boolean add(Logger logger) {
		// TODO Auto-generated method stub
		loggerRepository.save(logger);
		return true;
	}

	@Override
	public Boolean update(Logger logger) {
		// TODO Auto-generated method stub
		loggerRepository.save(logger);
		return true;
	}

	@Override
	public Boolean delete(Logger logger) {
		// TODO Auto-generated method stub
		loggerRepository.delete(logger);
		return true;
	}

	@Override
	public Boolean save(Logger logger) {
		// TODO Auto-generated method stub
		loggerRepository.save(logger);
		return true;
	}
	public List<Logger> list(){
		return loggerRepository.findAll();

}
}
