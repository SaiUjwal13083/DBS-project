package com.example.demo.services;

import java.util.List;

import com.example.demo.model.TransactionTable;

public interface TransactionService {
	public Boolean add(TransactionTable transaction);
	public Boolean update(TransactionTable transaction);
	public Boolean delete(TransactionTable transaction);
    public Boolean save(TransactionTable transaction);
	public List<TransactionTable> list();
	

}
