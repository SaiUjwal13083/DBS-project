package com.example.demo.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Bank;
import com.example.demo.repositories.BankRepository;
import com.example.demo.services.BankService;

@Service
public class BankServiceImpl implements BankService {
	@Autowired
	private BankRepository bankRepository;

	@Override
	public List<Bank> list() {
		// TODO Auto-generated method stub
		return bankRepository.findAll();
	}

	@Override
	public boolean delete(Bank bank) {
		bankRepository.delete(bank);
		return true;
	}

		@Override
	public Boolean add(Bank bank) {
			bankRepository.save(bank);
			return true;
		}

	
	@Override
	public Boolean save(Bank bank) {
		// TODO Auto-generated method stub
		bankRepository.save(bank);
		return true;
	}

	@Override
	public Boolean update(Bank bank) {
		// TODO Auto-generated method stub
		bankRepository.save(bank);
		return true;
	}

}


	