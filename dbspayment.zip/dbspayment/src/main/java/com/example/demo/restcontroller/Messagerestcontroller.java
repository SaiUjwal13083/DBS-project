package com.example.demo.restcontroller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Message;
import com.example.demo.services.MessageService;



@RestController
@RequestMapping("/Message")
@CrossOrigin(origins = "http://localhost:3000/")



public class Messagerestcontroller {
	@Autowired
	private MessageService messageService;
	@GetMapping("/message")
	public List<Message>listAllmessage(){
		return messageService.list();
	}
    @PostMapping("/message")
    public String savemessageObj(@RequestBody Message message) {
    	if(messageService.save(message)) {
    		return "Saved";
    	}else {
    		return "Failed";
    	}
    
		
	} 
    @PutMapping("/message")
    public String updateMessageObj(@RequestBody Message message ) {
    	if(messageService.update(message)){
    		return "updated";
    	}else {
    		return "Failed";
    	}
    
		
	} 
    @DeleteMapping("/message")
    public String deleteMessageObj(@RequestBody Message message ) {
    	if(messageService.delete(message)) {
    		return "deleted";
    	}else {
    		return "Failed";
    	}
    
		
	} 


}

