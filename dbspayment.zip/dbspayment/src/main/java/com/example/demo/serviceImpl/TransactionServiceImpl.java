package com.example.demo.serviceImpl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.model.TransactionTable;
import com.example.demo.repositories.TransactionRepository;
import com.example.demo.services.TransactionService;
@Service
public class TransactionServiceImpl implements TransactionService {
	private TransactionRepository transactionRepository;

	@Override
	public Boolean add(TransactionTable transaction) {
		// TODO Auto-generated method stub
		transactionRepository.save(transaction);
		return true;
	}

	@Override
	public Boolean update(TransactionTable transaction) {
		// TODO Auto-generated method stub
		transactionRepository.save(transaction);
		return true;
	}

	@Override
	public Boolean delete(TransactionTable transaction) {
		// TODO Auto-generated method stub
		transactionRepository.delete(transaction);
		return true;
	}

	@Override
	public Boolean save(TransactionTable transaction) {
		// TODO Auto-generated method stub
		transactionRepository.save(transaction);
		return true;
	}
	public List<TransactionTable> list(){
		return transactionRepository.findAll();

}
}
