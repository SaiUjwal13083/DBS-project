package com.example.demo.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
//@Service
//import org.springframework.beans.factory.annotation.Autowi
import org.springframework.stereotype.Service;

import com.example.demo.model.Customer;
import com.example.demo.repositories.CustomerRepository;
import com.example.demo.services.CustomerService;
@Service
public class CustomerServiceImpl implements CustomerService{
	@Autowired
	private CustomerRepository customerRepository;



@Override
public Boolean add(Customer customer) {
	// TODO Auto-generated method stub
	customerRepository.save(customer);
	return true;
}

@Override
public Boolean update(Customer customer) {
	// TODO Auto-generated method stub
	customerRepository.save(customer);
	return true;
	
}

@Override
public Boolean delete(Customer customer) {
	// TODO Auto-generated method stub
	customerRepository.save(customer);
	return true;
}

@Override
public Boolean save(Customer customer) {
	// TODO Auto-generated method stub
	customerRepository.save(customer);
	return true;
}
public List<Customer> list() {
	return customerRepository.findAll();
}
}
