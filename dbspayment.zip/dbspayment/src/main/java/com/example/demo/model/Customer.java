package com.example.demo.model;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity 
@Table(name = "customer_table")
public class Customer implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3591791467935994808L;
	@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
	private String customerId;
	@Column(unique = true,length = 50)
	private String  accountHolderName;
	private Boolean overDraftFlag;
	@Column(length = 1)
	private Double clearBalance;
	@Column(length = 10)
	private String customerAddress;
	@Column(length = 100)
	private String customerCity;
	@Column(length = 100)
	private String customerType;
	@Column(length = 1)
	public String getCustomerId() {
		return customerId;
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", accountHolderName=" + accountHolderName + ", overDraftFlag="
				+ overDraftFlag + ", clearBalance=" + clearBalance + ", customerAddress=" + customerAddress
				+ ", customerCity=" + customerCity + ", customerType=" + customerType + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(accountHolderName, clearBalance, customerAddress, customerCity, customerId, customerType,
				overDraftFlag);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		return Objects.equals(accountHolderName, other.accountHolderName)
				&& Objects.equals(clearBalance, other.clearBalance)
				&& Objects.equals(customerAddress, other.customerAddress)
				&& Objects.equals(customerCity, other.customerCity) && Objects.equals(customerId, other.customerId)
				&& Objects.equals(customerType, other.customerType)
				&& Objects.equals(overDraftFlag, other.overDraftFlag);
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public Boolean getOverDraftFlag() {
		return overDraftFlag;
	}
	public void setOverDraftFlag(Boolean overDraftFlag) {
		this.overDraftFlag = overDraftFlag;
	}
	public Double getClearBalance() {
		return clearBalance;
	}
	public void setClearBalance(Double clearBalance) {
		this.clearBalance = clearBalance;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public String getCustomerCity() {
		return customerCity;
	}
	public void setCustomerCity(String customerCity) {
		this.customerCity = customerCity;
	}
	public String getCustomerType() {
		return customerType;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	

}
