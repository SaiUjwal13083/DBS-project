package com.example.demo.restcontroller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Customeruser;

import com.example.demo.services.CustomeruserService;



@RestController
@RequestMapping("/customeruser")
@CrossOrigin(origins = "http://localhost:3000/")



public class Customeruserrestcontroller {
	@Autowired
	private CustomeruserService customeruserService;
	@GetMapping("/customeruser")
	public List<Customeruser>listAllcustomerUser(){
		return customeruserService.list();
	}
    @PostMapping("/customeruser")
    public String saveCustomeruserObj(@RequestBody Customeruser customeruser) {
    	if(customeruserService.save(customeruser)) {
    		return "Saved";
    	}else {
    		return "Failed";
    	}
    
		
	} 
    @PutMapping("/customeruser")
    public String updateCustomerUserObj(@RequestBody Customeruser customerUser ) {
    	if(customeruserService.update(customerUser)) {
    		return "updated";
    	}else {
    		return "Failed";
    	}
    
		
	} 
    @DeleteMapping("/customeruser")
    public String deleteCustomerUserObj(@RequestBody Customeruser customeruser) {
    	if(customeruserService.delete(customeruser)) {
    		return "deleted";
    	}else {
    		return "Failed";
    	}
    
		
	} 
}

