package com.example.demo.restcontroller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Logger;
import com.example.demo.services.LoggerService;






@RestController
@RequestMapping("/logger")
@CrossOrigin(origins = "http://localhost:3000/")


public class Loggerrestcontroller {
	@Autowired
	private LoggerService loggerService;
	@GetMapping("/logger")
	public List<Logger>listAlllogger(){
		return loggerService.list();
	}
    @PostMapping("/logger")
    public String saveLoggerObj(@RequestBody Logger logger) {
    	if(loggerService.save(logger)) {
    		return "Saved";
    	}else {
    		return "Failed";
    	}
    
		
	} 
    @PutMapping("/logger")
    public String updateEmployeeObj(@RequestBody Logger logger ) {
    	if(loggerService.update(logger)){
    		return "updated";
    	}else {
    		return "Failed";
    	}
    
		
	} 
    @DeleteMapping("/employee")
    public String deleteEmployeeObj(@RequestBody Logger logger ) {
    	if(loggerService.delete(logger)) {
    		return "deleted";
    	}else {
    		return "Failed";
    	}
    
		
	} 


}
