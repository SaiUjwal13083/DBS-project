package com.example.demo.services;

import java.util.List;

import com.example.demo.model.Bank;

//import com.example.demo.model.Bank;

//import com.example.demo.serviceImpl.Bank;

public interface BankService {
	public List<Bank> list();
	public Boolean save(Bank bank);
	public Boolean add(Bank bank);
	public Boolean update(Bank bank);
	public boolean delete(Bank bank);
	
	 

	 

 
}
