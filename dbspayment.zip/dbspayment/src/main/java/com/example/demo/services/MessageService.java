package com.example.demo.services;

import java.util.List;
import com.example.demo.model.Message;

public interface MessageService {
	public Boolean add(Message message);
	public Boolean update(Message message);
	public Boolean delete(Message message);
	public Boolean save(Message message);
	public List<Message> list();

}
