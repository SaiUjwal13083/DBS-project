package com.example.demo.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Currency;
import com.example.demo.repositories.CurrencyRepository;
import com.example.demo.services.CurrencyService;
@Service
public class CurrencyServiceImpl implements CurrencyService {
	@Autowired
	private CurrencyRepository currencyRepository;

	@Override
	public Boolean add(Currency currency) {
		// TODO Auto-generated method stub
	   currencyRepository.save(currency );
	   return true;
	}

	@Override
	public Boolean update(Currency currency) {
		// TODO Auto-generated method stub
		currencyRepository.save(currency );
		return true;
	}

	@Override
	public Boolean delete(Currency currency) {
		// TODO Auto-generated method stub
		currencyRepository.delete(currency);

		return true;
	}

	@Override
	public Boolean save(Currency currency) {
		// TODO Auto-generated method stub
		currencyRepository.save(currency );

		return true;
	}
	
	public List<Currency> list(){
		return currencyRepository.findAll();
	
		
	}

}
