package com.example.demo.serviceImpl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.model.TransferTypes;
import com.example.demo.repositories.TransferRepository;
import com.example.demo.services.TransfertypeService;
@Service
public class TransfertypeServiceImpl implements TransfertypeService{
	private TransferRepository transferRepository;

	@Override
	public Boolean add(TransferTypes transfertype) {
		// TODO Auto-generated method stub
		transferRepository.save(transfertype);
		return true;
	}

	@Override
	public Boolean update(TransferTypes transfertype) {
		// TODO Auto-generated method stub
		transferRepository.save(transfertype);
		return true;
	}

	@Override
	public Boolean delete(TransferTypes transfertype) {
		// TODO Auto-generated method stub
		transferRepository.delete(transfertype);
		return true;
	}

	@Override
	public Boolean save(TransferTypes transfertype) {
		// TODO Auto-generated method stub
		transferRepository.save(transfertype);
		return true;
	}
	@Override
	public List<TransferTypes> list(){
		return transferRepository.findAll();
		


}
}
