package com.example.demo.model;

import java.io.Serializable;

import java.util.Date;


import javax.persistence.CascadeType;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class TransactionTable implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3333342572181583986L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer transactionId;
	private String name;
	@Temporal(TemporalType.TIMESTAMP)
	private Date transferDate;
	
	private Double transferfees;
	private Double currencyAmount;
	@OneToOne(cascade = CascadeType.ALL) 
	private Customer customerId;
	private Currency currencyCode;
	private Bank senderBIC;
	private Bank receiverBIC; 
	private String receiverAccountHolderNumber; 
	private String receiverAccountHolderName;
	private TransferTypes transferTypeCode;
	private Message messageCode;
	private Boolean overdraft;
	public Integer getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getTransferDate() {
		return transferDate;
	}
	public void setTransferDate(Date transferDate) {
		this.transferDate = transferDate;
	}
	public Double getTransferfees() {
		return transferfees;
	}
	public void setTransferfees(Double transferfees) {
		this.transferfees = transferfees;
	}
	public Double getCurrencyAmount() {
		return currencyAmount;
	}
	public void setCurrencyAmount(Double currencyAmount) {
		this.currencyAmount = currencyAmount;
	}
	public Customer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Customer customerId) {
		this.customerId = customerId;
	}
	public Currency getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(Currency currencyCode) {
		this.currencyCode = currencyCode;
	}
	public Bank getSenderBIC() {
		return senderBIC;
	}
	public void setSenderBIC(Bank senderBIC) {
		this.senderBIC = senderBIC;
	}
	public Bank getReceiverBIC() {
		return receiverBIC;
	}
	public void setReceiverBIC(Bank receiverBIC) {
		this.receiverBIC = receiverBIC;
	}
	public String getReceiverAccountHolderNumber() {
		return receiverAccountHolderNumber;
	}
	public void setReceiverAccountHolderNumber(String receiverAccountHolderNumber) {
		this.receiverAccountHolderNumber = receiverAccountHolderNumber;
	}
	public String getReceiverAccountHolderName() {
		return receiverAccountHolderName;
	}
	public void setReceiverAccountHolderName(String receiverAccountHolderName) {
		this.receiverAccountHolderName = receiverAccountHolderName;
	}
	public TransferTypes getTransferTypeCode() {
		return transferTypeCode;
	}
	public void setTransferTypeCode(TransferTypes transferTypeCode) {
		this.transferTypeCode = transferTypeCode;
	}
	public Message getMessageCode() {
		return messageCode;
	}
	public void setMessageCode(Message messageCode) {
		this.messageCode = messageCode; 
	}
	public Boolean getOverdraft() {
		return overdraft;
	}
	public void setOverdraft(Boolean overdraft) {
		this.overdraft = overdraft;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}