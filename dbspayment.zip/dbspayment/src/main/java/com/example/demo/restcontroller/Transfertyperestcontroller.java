package com.example.demo.restcontroller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.TransferTypes;
import com.example.demo.services.TransfertypeService;



@RestController
@RequestMapping("/Transfertype")
@CrossOrigin(origins = "http://localhost:3000/")

 

public class Transfertyperestcontroller {
	@Autowired
	private TransfertypeService transfertypeService;
	@GetMapping("/Transfertype")
	public List<TransferTypes>listAlltransaction(){
		return transfertypeService.list();
	}
    @PostMapping("/Transaction")
    public String saveTransfertypeObj(@RequestBody TransferTypes transfertype) {
    	if(transfertypeService.save(transfertype)) {
    		return "Saved";
    	}else {
    		return "Failed";
    	}
    
		
	} 
    @PutMapping("/transfertype")
    public String updateTransfertypeObj(@RequestBody TransferTypes transfertypes ) {
    	if(transfertypeService.update(transfertypes)){
    		return "updated";
    	}else {
    		return "Failed";
    	}
    
		
	} 
    @DeleteMapping("/transfertype")
    public String deleteTransfertypesObj(@RequestBody TransferTypes transfertypes ) {
    	if(transfertypeService.delete(transfertypes)) {
    		return "deleted";
    	}else {
    		return "Failed";
    	}
    
		
	} 


}





