package com.example.demo.services;

import java.util.List;

import com.example.demo.model.TransferTypes;

public interface TransfertypeService {
	public Boolean add(TransferTypes transfertype);
	public Boolean update(TransferTypes transfertype);
	public Boolean delete(TransferTypes transfertype);
    public Boolean save(TransferTypes transfertype);
    public List<TransferTypes> list();


}
