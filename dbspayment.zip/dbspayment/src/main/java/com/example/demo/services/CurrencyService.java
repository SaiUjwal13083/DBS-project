package com.example.demo.services;

import java.util.List;

import com.example.demo.model.Currency;

public interface CurrencyService{
	public Boolean add(Currency currency);
	public Boolean update(Currency currency);

	public Boolean delete(Currency currency);
	public Boolean save(Currency currency);
	List<Currency> list();


	

}
