package com.example.demo.restcontroller;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Customer;
import com.example.demo.services.CustomerService;


@RestController
@RequestMapping("/customer")
@CrossOrigin(origins = "http://localhost:3000/")

public class Customerrestcontroller {
	@Autowired
	private CustomerService customerservice;

    @GetMapping("/customer")
	public List<Customer>  listAllCustomer(){
		return customerservice.list();
	}
    @PostMapping("/upload")
    public List<Customer> bulkUpload(@RequestBody List<Customer> custList){
    	for(Customer cust:custList) {
    		customerservice.add(cust);
    	}
    	return custList;
    }
    @PostMapping("/")
    public String saveCustomerObj(@RequestBody Customer customer) {
    	if(customerservice.save(customer)) {
    		return "Saved";
    	}else {
    		return "Failed";
    	}
    
		
	} 
    @PutMapping("/customer")
    public String updateCustomerObj(@RequestBody Customer customer ) {
    	if(customerservice.update(customer)) {
    		return "updated";
    	}else {
    		return "Failed";
    	}
    
		
	} 
    @DeleteMapping("/customer")
    public String deleteCustomerObj(@RequestBody Customer customer) {
    	if(customerservice.delete(customer)) {
    		return "deleted";
    	}else {
    		return "Failed";
    	}
    
		
	} 
}





