package com.example.demo.serviceImpl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.model.Message;
import com.example.demo.repositories.MessageRepository;
import com.example.demo.services.MessageService;
@Service
public class MessageServiceImpl implements MessageService{
	private MessageRepository messageRepository;

	@Override
	public Boolean add(Message message) {
		// TODO Auto-generated method stub
		messageRepository.save(message);
		return null;
	}

	@Override
	public Boolean update(Message message) {
		// TODO Auto-generated method stub
		messageRepository.save(message);
		return null;
	}

	@Override
	public Boolean delete(Message message) {
		// TODO Auto-generated method stub
		messageRepository.delete(message);
		return true;
	}

	@Override
	public Boolean save(Message message) {
		// TODO Auto-generated method stub
		messageRepository.save(message);
		return true;
	}
	public List<Message> list(){
		return messageRepository.findAll();

}
}
